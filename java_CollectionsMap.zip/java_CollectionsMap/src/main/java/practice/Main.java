package practice;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        PhoneBook phoneBook = new PhoneBook();
        String phone = "";
        String name = "";

        while (true) {
            System.out.println("Введите номер, имя или команду:");
            String input = new Scanner(System.in).nextLine();
            if (input.equals("LIST")){
                System.out.println(phoneBook.getAllContacts());
            } else if (input.matches("\\d+")) {
                phone = input;
            } else if (input.matches("\\D+")) {
                name = input;
            }
            phoneBook.addContact(phone, name);
        }
    }
}
